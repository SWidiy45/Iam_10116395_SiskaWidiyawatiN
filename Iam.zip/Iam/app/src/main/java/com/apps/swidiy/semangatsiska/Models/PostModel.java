package com.apps.swidiy.semangatsiska.Models;

public class PostModel {
    private String judul;
    private String cerita;

    public PostModel() {
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getCerita() {
        return cerita;
    }

    public void setCerita(String cerita) {
        this.cerita = cerita;
    }
}

package com.apps.swidiy.semangatsiska.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.apps.swidiy.semangatsiska.Models.PostModel;
import com.apps.swidiy.semangatsiska.R;


import java.util.List;

public class PostingAdapter extends RecyclerView.Adapter<PostingAdapter.MyViewHolder> {
    Context mContext;
    List<PostModel> mData;

    public PostingAdapter(Context mContext, List<PostModel> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View row = LayoutInflater.from(mContext).inflate(R.layout.view_item,parent,false);
        return new MyViewHolder(row);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.tvTitle.setText(mData.get(position).getJudul());
        holder.tvDesc.setText(mData.get(position).getCerita());



    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView tvTitle;
        TextView tvDesc;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvTitle = itemView.findViewById(R.id.title_tv);
            tvDesc = itemView.findViewById(R.id.description_tv);
        }
    }

}

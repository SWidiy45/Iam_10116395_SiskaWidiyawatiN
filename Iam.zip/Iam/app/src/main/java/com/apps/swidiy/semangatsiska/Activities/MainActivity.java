package com.apps.swidiy.semangatsiska.Activities;

import android.os.Bundle;

import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.apps.swidiy.semangatsiska.Fragments.HistoryFragment;
import com.apps.swidiy.semangatsiska.Fragments.FavoriteFragment;
import com.apps.swidiy.semangatsiska.Fragments.HomeFragment;
import com.apps.swidiy.semangatsiska.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private TextView mTextMessage;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    getSupportActionBar().setTitle("Timeline");
                    getSupportFragmentManager().beginTransaction().replace(R.id.fl_container, new HomeFragment()).commit();
                    mTextMessage.setText("");
                    return true;
                case R.id.navigation_favorite:
                    getSupportActionBar().setTitle("Favorite");
                    getSupportFragmentManager().beginTransaction().replace(R.id.fl_container, new FavoriteFragment()).commit();
                    mTextMessage.setText("");
                    return true;
                case R.id.navigation_history:
                    getSupportActionBar().setTitle("History");
                    getSupportFragmentManager().beginTransaction().replace(R.id.fl_container, new HistoryFragment()).commit();
                    mTextMessage.setText("");
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.navigation);

        mTextMessage = findViewById(R.id.message);
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        getSupportActionBar().setTitle("Timeline");
        getSupportFragmentManager().beginTransaction().replace(R.id.fl_container, new HomeFragment()).commit();
        mTextMessage.setText("");
    }



}

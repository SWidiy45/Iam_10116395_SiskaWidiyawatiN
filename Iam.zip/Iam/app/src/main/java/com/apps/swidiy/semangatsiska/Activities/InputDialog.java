package com.apps.swidiy.semangatsiska.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.apps.swidiy.semangatsiska.Models.PostModel;
import com.apps.swidiy.semangatsiska.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.StorageReference;


public class InputDialog extends AppCompatActivity {

    EditText judulpost, artikelpost;
    Button postBtn;
    StorageReference mStorageReference;
    DatabaseReference mDatabaseReference;
    PostModel postModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_input);

        judulpost = (EditText) findViewById(R.id.edt_di_title);
        artikelpost = (EditText) findViewById(R.id.edt_di_cerita);
        postBtn = (Button) findViewById(R.id.btn_di_simpan);
        postModel = new PostModel();
        mDatabaseReference= FirebaseDatabase.getInstance().getReference().child("Data");


        //upload ke firebase
        postBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // memanggil method upload data
                uploadDataToFirebase();

                Intent intent = new Intent(InputDialog.this, MainActivity.class);
                startActivity(intent);


            }
        });

    }

    private void uploadDataToFirebase() {
        postModel.setJudul(judulpost.getText().toString().trim());
        postModel.setCerita(artikelpost.getText().toString().trim());
        mDatabaseReference.push().setValue(postModel);
        Toast.makeText(this,"Cerita sudah di upload", Toast.LENGTH_LONG).show();

    }
}
